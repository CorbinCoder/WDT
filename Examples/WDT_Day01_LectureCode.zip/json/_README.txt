An interesting read about various ways of JSON processing in C#:

https://michaelscodingspot.com/the-battle-of-c-to-json-serializers-in-net-core-3/